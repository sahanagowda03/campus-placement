This directory contains machine learning models in binary pickle file
