export const SKILLS_ICON_PATHS = {
    'Machine Learning': '/static/images/icons/ml_icon.png',
    'Web Development': '/static/images/icons/web_dev_icon.png',
    'Cloud Computing': '/static/images/icons/cloud_icon.png',
    'Data Structures and Algorithms': '/static/images/icons/dsa_icon.png',
};
