export const PAGE_PATHS = {
    INSIGHTS: '/placement-insights',
    CAMPUS_PLACEMENT_ANALYZER: '/campus-placement-analyzer',
    STUDENT_PLACEMENT_ANALYZER: '/student-placement-analyzer',
};
