export const OverallCampusSalaryStats = () => {
    return <div>OverallCampusSalaryStats</div>;
};
